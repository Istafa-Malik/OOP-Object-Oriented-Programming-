#include<iostream>
#include<string>
using namespace std;
struct players				
{
 string fn;
string ln;
 int rank,goalscored,age;
}
P1;					
void assign(players P1[],int &i,int& entry) 	
{
 if(entry==1)							
{cout<<"Enter a new First Name ";
cin>>P1[i].fn;
cout<<"Successfully Updated ";}
if(entry==2)							
{cout<<"Enter a new Last Name ";
cin>>P1[i].ln;
cout<<"Successfully Updated ";}
if(entry==3)							
{
cout<<"Enter a new Age ";
cin>>P1[i].age;
cout<<"Successfully Updated ";}
if(entry==4)							
{
cout<<"Enter a new Rank ";
cin>>P1[i].rank;
cout<<"Successfully Updated ";}
if(entry==5)							
{
cout<<"Enter a New No. of  Goals Scored ";
cin>>P1[i].goalscored;
cout<<"Successfully Updated ";}
cout<<endl;}
void New_player(players P1[],int *n)		
{
	cout<<"Enter The First name of the Player ";  
cin>>P1[*n].fn;
cout<<"Enter The Last name of the Player ";
cin>>P1[*n].ln;
cout<<"Enter The Age of the Player ";
cin>>P1[*n].age;
cout<<"Enter The Rank of the Player ";
cin>>P1[*n].rank;
cout<<"Enter The No. of Goals Scored By the "<<P1[*n].fn<<" ";
cin>>P1[*n].goalscored;
cout<<endl<<endl;}
void update(players P1[],int *n) 			
{			string name,lname;
int entry,entry1,counter[5]={0,0,0,0,0};
cout<<"Enter num based on which entry of the player you want to change ";
cout<<"1. For Changing First Name "<<"2. For Changing Last Name ";
cout<<"3. For Changing Age "<<"4. For Changing Rank ";
cout<<"5. For Changing No. of Goals Scored ";
cin>>entry;
cout<<"Enter the First and Last Name of the Player Who's Record You want to Update ";
cin>>name;
cout<<"Now, Enter the Last Name ";
cin>>lname;
for(int i=0;i<*n;i++)
{
if(name==P1[i].fn && lname==P1[i].ln) {
assign(P1,i,entry);
counter[1]++;}}
if(counter[1]!=1 ) 		
{cout<<"No Player in the Given List has "<<name<<" "<<lname<<
cout<<endl<<" Enter the Rank of the Player Who's Record You want to Update ";
cin>>entry1;
for(int i=0;i<*n;i++)
{
if(entry1==P1[i].rank)
{
assign(P1,i,entry);
counter[2]++;}}
if(counter[2]!=1)
{cout<<"No Player in the Given List has "<<entry1<<" as their rank ";
cout<<" Enter the Age of the Player Who's Record You want to Update";
cin>>entry1;
for(int i=0;i<*n;i++)
{if(entry1==P1[i].age)
{
assign(P1,i,entry);
counter[3]++;}}
if(counter[3]!=1 ) 
{ cout<<"No Player in the Given List has "<<entry1<<" as their age ";
cout<<" Enter the No. of Goal scored by the Player Who's Record You want to Update ";
cin>>entry1;
for(int i=0;i<*n;i++)
{if(entry1==P1[i].goalscored)
{
assign(P1,i,entry);
counter[4]++;}}
if(counter[4]!=1 && counter[3]!=1 && counter[2]!=1 && counter[1]!=1 && counter[0]!=1)
cout<<"Sorry, No Player Matches the Current Data ";}
}}cout<<endl<<endl;}
void search(players P1[],int *n);			
{
  string name,lname;
cout<<"Enter the First and Last Name of the Player Who's Record You want to Search ";
cin>>name>>lname;
for(int i=0;i<*n;i++)
{if(name==P1[i].fn && lname==P1[i].ln) 		
{
 cout<<"First Name of Player is "<<P1[i].fn<<endl;
cout<<"Last Name of Player is "<<P1[i].ln<<endl;
cout<<"Age of Player is "<<P1[i].age<<endl;
cout<<"Rank of Player is "<<P1[i].rank<<endl;
cout<<"No. of Goals Scored By Player is "<<P1[i].goalscored<<endl;
}}cout<<endl<<endl;}
void display(players P1[],int *n)
{
  int i;
cout<<" Displaying the data of Players ";
for(int i=0;i<*n;i++)
{
cout<<"First Name of Player is "<<P1[i].fn<<endl;
cout<<"Last Name of Player is "<<P1[i].ln<<endl;
cout<<"Age of Player is "<<P1[i].age<<endl;
cout<<"Rank of Player is "<<P1[i].rank<<endl;
cout<<"No. of Goals Scored By Player is "<<P1[i].goalscored<<endl;
cout<<endl<<endl;
}}int main ()
{  
int no,n1,counte=0;
int* n=&n1,*counter=&counte;
cout<<"Enter the No. of players you want to have in the Team ";
cin>>n1;
players P1[n1];
{
New_player(P1,counter);
*counter=*counter+1;
}
do{cout<<"Enter the Desired Num according to the task you want to be performed"<<endl;
cout<<"1. Add a New Player "<<endl<<"2. Update a Player's Record "<<endl<<"3. Search For a Player "<<endl<<"4. Display the complete list of Players ";
cout<<endl<<"5. Exit the Program "<<endl;
cin>>no;
if(no==1 )
{
if(*counter>=n1) 
cout<<"No. of Players Exceed the given limit ";
if(*counter<n1)
{
New_player(P1,counter);
*counter=*counter+1;
}}
if(no==2)
update(P1,n);
if(no==3)
search(P1,n);
if(no==4)
display(P1,n);
}
while(no!=5);
return 0;
}
